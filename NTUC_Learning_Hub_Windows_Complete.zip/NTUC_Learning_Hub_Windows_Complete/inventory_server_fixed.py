from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import os
import json

app = Flask(__name__, static_folder='public')
CORS(app)  # Habilitar CORS para todas las rutas

# Configuración para servir archivos estáticos
@app.route('/<path:filename>')
def serve_static(filename):
    root_dir = os.path.dirname(os.path.abspath(__file__))
    return send_from_directory(os.path.join(root_dir, 'public'), filename)

# Ruta para buscar en el inventario
@app.route('/api/search', methods=['GET'])
def search_inventory():
    try:
        query = request.args.get('query', '').lower()
        
        # Cargar el inventario desde el archivo JSON
        inventory_path = os.path.join('public', 'data', 'InventarioCompleto.json')
        with open(inventory_path, 'r', encoding='utf-8') as f:
            inventory = json.load(f)
        
        # Buscar coincidencias
        results = []
        for item in inventory:
            if query in item.get('nombre', '').lower() or \
               query in item.get('descripcion', '').lower() or \
               query in item.get('categoria', '').lower():
                results.append(item)
        
        return jsonify({
            'success': True,
            'count': len(results),
            'results': results
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Ruta para obtener todos los elementos del inventario
@app.route('/api/inventory', methods=['GET'])
def get_inventory():
    try:
        # Cargar el inventario desde el archivo JSON
        inventory_path = os.path.join('public', 'data', 'InventarioCompleto.json')
        with open(inventory_path, 'r', encoding='utf-8') as f:
            inventory = json.load(f)
        
        return jsonify({
            'success': True,
            'count': len(inventory),
            'results': inventory
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Ruta principal - Servir el index.html
@app.route('/')
def index():
    return send_from_directory('dist', 'index.html')

if __name__ == '__main__':
    # Crear las carpetas necesarias si no existen
    os.makedirs('public/data', exist_ok=True)
    
    # Verificar si el archivo de inventario existe, si no, crear uno de ejemplo
    inventory_path = os.path.join('public', 'data', 'InventarioCompleto.json')
    if not os.path.exists(inventory_path):
        with open(inventory_path, 'w', encoding='utf-8') as f:
            json.dump([], f, ensure_ascii=False, indent=2)
    
    # Iniciar el servidor
    print("Servidor de inventario iniciado en http://localhost:5003")
    print("Presiona Ctrl+C para detener el servidor")
    app.run(host='0.0.0.0', port=5003, debug=True)

# Este script debe guardarse como 'inventory_server_fixed.py' en la carpeta raíz del proyecto.
